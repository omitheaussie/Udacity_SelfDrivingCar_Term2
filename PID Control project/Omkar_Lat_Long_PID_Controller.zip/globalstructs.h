#ifndef GLOBALSTRUCTS_H_
#define GLOBALSTRUCTS_H_

//PID errors
struct errors {
	double p_error_, i_error_, d_error_, total_error_;
};

//cross track error components
struct ctes {
	double cte_, cte_prev_, cte_mem_;
};

//Coefficients and velocity
struct coeffs {
	double Kp, Ki, Kd;
	double Kp_, Ki_, Kd_;
	double alpha_p, alpha_i, alpha_d;
	double  v;
	double  keep_perc;
};

#endif