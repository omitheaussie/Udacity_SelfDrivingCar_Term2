#include "PID.h"

using namespace std;

/*
* TODO: Complete the PID class.
*/

PID::PID() {}

PID::~PID() {}

void PID::UpdateCoefficients(coeffs coeff) {

	this->coeffs_.Kp = coeff.Kp;
	this->coeffs_.Ki = coeff.Ki;
	this->coeffs_.Kd = coeff.Kd;

	this->coeffs_.alpha_p = coeff.alpha_p;
	this->coeffs_.alpha_i = coeff.alpha_i;
	this->coeffs_.alpha_d = coeff.alpha_d;

	this->coeffs_.v = coeff.v;

	this->coeffs_.Kp_ = this->coeffs_.Kp + coeff.alpha_p * coeff.v;
	this->coeffs_.Ki_ = this->coeffs_.Ki + coeff.alpha_i * coeff.v;
	this->coeffs_.Kd_ = this->coeffs_.Kd + coeff.alpha_d * coeff.v;

	return;
}

void PID::Init(coeffs coeff) {

	PID::UpdateCoefficients(coeff);
	this->coeffs_.keep_perc = coeff.keep_perc;
	this->errors_.p_error_= 0;
	this->errors_.i_error_ = 0;
	this->errors_.d_error_ = 0;
	this->errors_.total_error_ = 0;
	
	this->cte_.cte_ = 0;
	this->cte_.cte_prev_ = 0;
	this->cte_.cte_mem_ = 0;

	return;
}


void PID::UpdateError(double cte) {

	this->cte_.cte_prev_ = this->cte_.cte_;
	this->cte_.cte_ = cte;
	this->cte_.cte_mem_ = this->coeffs_.keep_perc * this->cte_.cte_mem_ + this->cte_.cte_;

	this->errors_.p_error_ = this->coeffs_.Kp_* this->cte_.cte_;
	this->errors_.i_error_ = this->coeffs_.Ki_ * this->cte_.cte_mem_;
	this->errors_.d_error_ = this->coeffs_.Kd_* (this->cte_.cte_ - this->cte_.cte_prev_);

	return;

}

double PID::TotalError() {

	this->errors_.total_error_= this->errors_.p_error_ + this->errors_.d_error_ + this->errors_.i_error_;

	return this->errors_.total_error_;

}
