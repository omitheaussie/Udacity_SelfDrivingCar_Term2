#ifndef PID_H
#define PID_H
#include "globalstructs.h"

class PID {
public:
	//Errors
	errors errors_;
	
	//cross track error components
	ctes cte_;
	
	//Coefficients and velocity
	coeffs coeffs_;
	
	//Constructor
	PID();
	
	//Destructor.
	virtual ~PID();
	
	//Initialize PID.
	void Init(coeffs coeff);
	
	//Update PID coefficients.
	void UpdateCoefficients(coeffs coeff);
	
	//Update the PID error variables given cross track error.
	void UpdateError(double cte);
	
	//Calculate the total PID error.
	double TotalError();
};

#endif /* PID_H */